import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String test = scanner.nextLine();

        System.out.println(getString(test));

    }


    public static String getString(String data){
        if (data.length()<2){
            return null;
        }

        char[] charList = data.toCharArray();
        int local = 0;
        int max = 0;
        int i = 1;
        int flag = 0;
        for (int x = 0 ;x < charList.length;x++){
            while ((x-i)>=0&&(x+i)<charList.length&&charList[x-i]==charList[x+i]){
                    i++;
            }
            if((max+1)<i){
                max=i-1;
                local = x;
                flag =1;

            }
            i = 1;
        }


        for (int x = 0 ;x < charList.length;x++){
            while ((x-i+1)>=0&&(x+i)<charList.length&&charList[x-i+1]==charList[x+i]){
                i++;
            }
            if((max+1)<i){
                max=i-1;
                local = x;
                flag =2;

            }
            i = 1;
        }

        for (int x = 0 ;x < charList.length;x++){
            while ((x-i)>=0&&(x+i-1)<charList.length&&charList[x-i]==charList[x+i-1]){
                i++;
            }
            if((max+1)<i){
                max=i-1;
                local = x;
                flag =3;

            }
            i = 1;
        }

        StringBuilder result = new StringBuilder();
        if (flag==1) {
            for (int y = (local - max); y <= (local + max); y++) {
                result.append(charList[y]);

            }
        }else if (flag==2){
            for (int y = (local - max+1); y <= (local + max); y++) {
                result.append(charList[y]);

            }

        }else if (flag==3){
            for (int y = (local - max); y <= (local + max-1); y++) {
                result.append(charList[y]);

            }

        }        //        int count = 0;
//        for (int z = (local-max);z<=(local+max);z++){
//                if((z+1)<charList.length&&charList[z]==charList[z+1]){
//                    count++;
//                }
//        }
//        if (count==(result.length())){
//            result.append(charList[local+max+1]);
//
//        }
        if (result.length()>1) {
            return result.toString();
        }else {
            return null;
        }

    }


}



//算法实现：在大文本中查找最长的回文串（至少2个字符，该字符串反序之后同原字符串一样），
// 并返回（如果没有返回Null）【测试用例：aaabbaccbababac，返回babab】。